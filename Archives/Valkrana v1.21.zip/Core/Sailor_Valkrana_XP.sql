-- // MomentIllustrations
INSERT INTO MomentIllustrations
		(MomentIllustrationType,			MomentDataType,			GameDataType,				Texture)
VALUES	('MOMENT_ILLUSTRATION_UNIQUE_UNIT',	'MOMENT_DATA_UNIT',		'UNIT_SAILOR_VALKRANA_UU',	'Moment_UniqueUnit_Sailor_Valkrana_UU.dds'),
		('MOMENT_ILLUSTRATION_RELIGION',	'MOMENT_DATA_RELIGION', 'RELIGION_SAILOR_ILYANA',	'PM_FoundedReligion_Ilyana');